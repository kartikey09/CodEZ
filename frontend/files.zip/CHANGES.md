# Frontend ↔ backend wiring — changes

Goal: make the partially-built frontend actually connect to the Go backend, with
**login** and **code submission** working end to end against the real `/api/*` contract.

The submission/polling and problem-fetching code was already wired correctly. The
breakage was concentrated in a few spots. Below is exactly what changed and why.

## Files

### 1. `frontend/src/components/login.tsx`  — NEW (the real blocker)
`App.tsx` does `import { Login } from '@/components/login'`, but the file didn't
exist, so `tsc -b` / `vite build` / `vite dev` all failed before anything could run.

This component:
- `POST {API_BASE}/api/login` with `{ username, password }`.
- On `{ success: true, token }`, writes `localStorage['student-auth']` (the token)
  and `localStorage['student-username']`, then calls `onLogin()`. Those are the exact
  keys `App.tsx` reads to gate the app and clears on logout — so the contract matches.
- On `{ success: false }` shows the server's `message` ("Invalid credentials").
- On a network failure shows a clear "Cannot reach the server. Is the backend running
  on :8082?" message instead of a silent console error.
- Has a "Use demo account" button that fills a known seeded login.

### 2. `frontend/vite.config.ts`  — MODIFIED (dev couldn't reach the backend)
`API_BASE` is `''` (relative paths). In production that works because nginx proxies
`location /api/ -> backend:8082`. But `npm run dev` (Vite on :5173) had nothing
forwarding `/api/*`, so every call 404'd against the dev server.

Added a dev proxy that mirrors the nginx rule:
```
server.proxy['/api'] -> http://localhost:8082   (override via VITE_BACKEND_ORIGIN)
```
Now the same relative `/api` paths work in both dev and prod — no code branching.

### 3. `frontend/src/components/ide.tsx`  — MODIFIED
- Default boilerplate was **Python**, but the editor defaults to **Java** and the
  judge only compiles Java — a fresh "Submit" would compilation-error. Changed the
  seed to the Java `Solution` template so the default submission actually runs.
- Passes `problemId={id}` (the problem UUID from the route) into `<CodeEditor>`.

### 4. `frontend/src/components/code-editor.tsx`  — MODIFIED
- Added an optional `problemId` prop and included `problem_id` in the `/api/submit`
  body. Previously every submission omitted it and the backend fell back to one
  hardcoded problem; now submissions tie to the problem actually open.
  (The submit→poll loop itself was already correct and is unchanged.)

## Backend contract this targets (`backend/main.go`)
- `POST /api/login`     → `{ success, message, token }`
- `GET  /api/problems`  → `[{ id, slug, title, points }]`
- `GET  /api/problem?id=…`
- `POST /api/submit`    `{ source_code, language:"java", test_cases[], problem_id }` → `{ submission_id, status }`
- `GET  /api/status/{id}` → polled until terminal verdict

## Test credentials (from `02_seed_data.sql`)
Any of: `aarav`, `admin1`, `prof_smith`, `priya`, `rohan`, `isha`, `vihaan`,
`ananya`, `kabir`, `meera` — all with password **`password123`**.

## Run it
Full stack (recommended — brings up db, kafka/judge, backend, frontend):
```
docker compose up --build
# open http://localhost:3000
```

Frontend dev against a running backend on :8082:
```
cd frontend
npm install
npm run dev          # http://localhost:5173, /api proxied to :8082
```

Verified: `npm run build` (`tsc -b && vite build`) passes with these changes.
