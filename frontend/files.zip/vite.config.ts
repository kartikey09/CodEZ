import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import path from "path"

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  // Where the Go backend is reachable during local `npm run dev`.
  // Override with VITE_BACKEND_ORIGIN if your backend runs elsewhere.
  const backend = env.VITE_BACKEND_ORIGIN || 'http://localhost:8082'

  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        "@": path.resolve(__dirname, "./src"),
      },
    },
    server: {
      // Mirrors the nginx prod rule (location /api/ -> backend:8082) so the app
      // can use relative /api paths (API_BASE = '') in dev and prod alike.
      proxy: {
        '/api': {
          target: backend,
          changeOrigin: true,
        },
      },
    },
  }
})
