import { useCallback, useEffect, useRef, useState } from 'react'
import { api, ApiError } from '@/lib/api'
import type { StandingsResponse } from '@/lib/types'
import { Loader2, RefreshCw } from 'lucide-react'

// contest-api has no public "current contest" endpoint yet, so the board needs
// an explicit contest id. Set VITE_CONTEST_ID to skip the input.
const ENV_CONTEST_ID = import.meta.env.VITE_CONTEST_ID as string | undefined

export function Leaderboard() {
  const [contestId, setContestId] = useState(ENV_CONTEST_ID ?? '')
  const [data, setData] = useState<StandingsResponse | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const timer = useRef<number | null>(null)

  const load = useCallback(
    async (auto = false) => {
      const id = Number(contestId)
      if (!Number.isFinite(id) || contestId === '') return
      if (!auto) setLoading(true)
      try {
        const res = await api.getStandings(id)
        setData(res)
        setError(null)
        timer.current = window.setTimeout(() => void load(true), 5000) // live-ish refresh
      } catch (err) {
        setError(err instanceof ApiError ? err.message : 'Failed to load standings.')
      } finally {
        setLoading(false)
      }
    },
    [contestId],
  )

  useEffect(() => {
    if (ENV_CONTEST_ID) void load()
    return () => {
      if (timer.current !== null) window.clearTimeout(timer.current)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <div className="flex-1 w-full overflow-y-auto p-8 font-sans">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-8 gap-4 flex-wrap">
          <h2 className="text-3xl font-bold text-white tracking-tight">Leaderboard</h2>
          <div className="flex items-center gap-2">
            <input
              value={contestId}
              onChange={(e) => setContestId(e.target.value.replace(/[^0-9]/g, ''))}
              placeholder="Contest ID"
              className="h-9 w-32 px-3 rounded-md bg-input border border-border text-sm text-foreground focus:outline-none focus:border-accent"
            />
            <button
              onClick={() => {
                if (timer.current !== null) window.clearTimeout(timer.current)
                void load()
              }}
              className="h-9 px-3 rounded-md bg-accent text-accent-foreground text-sm font-semibold flex items-center gap-1.5 hover:bg-accent/90 transition"
            >
              <RefreshCw size={14} /> Load
            </button>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-40">
            <Loader2 className="animate-spin h-8 w-8 text-accent" />
          </div>
        ) : error ? (
          <div className="text-center text-destructive py-12 bg-card rounded-2xl border border-border">{error}</div>
        ) : !data ? (
          <div className="text-center text-muted-foreground py-12 bg-card rounded-2xl border border-border">
            Enter a contest ID and press Load.
          </div>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-border">
            <table className="w-full text-sm">
              <thead className="bg-secondary/40 text-muted-foreground">
                <tr className="text-left">
                  <th className="px-4 py-3 font-semibold">#</th>
                  <th className="px-4 py-3 font-semibold">Contestant</th>
                  <th className="px-4 py-3 font-semibold text-center">Solved</th>
                  <th className="px-4 py-3 font-semibold text-center">Penalty</th>
                  {data.problems.map((p) => (
                    <th key={p} className="px-3 py-3 font-semibold text-center">
                      {p}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {data.rows.map((row) => (
                  <tr key={row.userId} className="bg-card hover:bg-secondary/20 transition-colors">
                    <td className="px-4 py-3 font-mono text-muted-foreground">{row.rank}</td>
                    <td className="px-4 py-3 text-foreground font-medium">{row.displayName}</td>
                    <td className="px-4 py-3 text-center font-bold text-accent">{row.solved}</td>
                    <td className="px-4 py-3 text-center text-muted-foreground">{row.penalty}</td>
                    {row.cells.map((c) => (
                      <td
                        key={c.label}
                        className={`px-3 py-3 text-center text-xs font-mono ${
                          c.state === 'solved'
                            ? 'bg-green-500/15 text-green-400'
                            : c.state === 'attempted'
                              ? 'bg-destructive/15 text-destructive'
                              : 'text-muted-foreground/40'
                        }`}
                      >
                        {c.state === 'solved'
                          ? `+${c.attempts > 1 ? c.attempts - 1 : ''} ${c.acMinute ?? ''}`.trim()
                          : c.state === 'attempted'
                            ? `-${c.attempts}`
                            : '·'}
                      </td>
                    ))}
                  </tr>
                ))}
                {data.rows.length === 0 && (
                  <tr>
                    <td colSpan={4 + data.problems.length} className="px-4 py-12 text-center text-muted-foreground bg-card">
                      No judged submissions yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
