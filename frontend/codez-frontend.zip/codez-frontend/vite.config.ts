import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import path from 'path'

// Two Spring Boot services back this SPA:
//   auth-service  → /auth/*   (default :8081)
//   contest-api   → /api/*    (default :8080)
// We proxy both so the browser sees a single origin (http://localhost:5173).
// That keeps the `sid` session cookie first-party (no CORS, no SameSite issues).
// Override targets with VITE_AUTH_ORIGIN / VITE_API_ORIGIN if your ports differ.
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  const authOrigin = env.VITE_AUTH_ORIGIN || 'http://localhost:8081'
  const apiOrigin = env.VITE_API_ORIGIN || 'http://localhost:8080'

  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: { '@': path.resolve(__dirname, './src') },
    },
    server: {
      host: true,
      port: 5173,
      proxy: {
        '/auth': { target: authOrigin, changeOrigin: true },
        '/api': { target: apiOrigin, changeOrigin: true },
      },
    },
  }
})
