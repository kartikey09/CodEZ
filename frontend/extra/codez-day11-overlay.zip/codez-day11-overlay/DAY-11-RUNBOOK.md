# CodEZ — Day 11 Runbook (student frontend, wired live)

Day 11 turns the empty `frontend/` scaffold into the **complete student web app**, wired to the
real CodEZ services and to the Day-10 realtime WebSocket. It also adds one small backend endpoint
the UI needs. The frontend was **type-checked and production-built in a sandbox** (`tsc -b && vite
build`, 1808 modules, clean) — that is its compile proof, since Java can't be compiled here.

> Scope note. Your roadmap's "Day 11" card is the admin panel. You deferred all frontend work, so
> this build is the whole **student** frontend (login → change password → problems → editor →
> submit → live verdict → live board). The **admin panel becomes your Day 12.** Everything here
> keeps the visual design, versions, and package choices from your `frontend/files.zip` WIP — only
> the data layer was rewritten, because that WIP targeted a *different* backend (see the translation
> table below).

---

## 1. Apply order

```bash
# from the repo root (contest-platform/), on a Day-11 branch off scoreboard+Day-10
tar xzf codez-day11-overlay.tar.gz          # drops services/… and frontend/… in place

# backend: the one new endpoint + its test
cd services/contest-api
./mvnw clean verify                          # compiles ContestController + green ContestControllerTest

# frontend: install the added deps, then dev
cd ../../frontend
npm install                                  # package.json/lock now include router, lucide, hljs, tailwind
npm run dev                                   # http://localhost:5173
```

`npm install` is required — Day 11 adds five dependencies (below). The overlay ships the updated
`package.json` **and** `package-lock.json`, so the install is deterministic.

### Added dependencies (resolved in the sandbox)

| Package | Version | Why |
|---|---|---|
| `react-router-dom` | ^7.18.1 | client routing (login / change-pw / problems / editor / standings / submissions) |
| `lucide-react` | ^1.23.0 | icon set your components already import |
| `highlight.js` | ^11.11.1 | editor syntax overlay (core build + 4 grammars) |
| `tailwindcss` | ^4.3.2 | styling (v4, no config file — tokens live in `index.css`) |
| `@tailwindcss/vite` | ^4.3.2 | Tailwind v4's Vite plugin |

Your existing pins (React 19.2, Vite 8, TypeScript ~6.0, the ESLint 10 flat config) are **unchanged**.

---

## 2. Run order (services the frontend talks to)

The dev server proxies to these, so start them first (each in its own terminal, on `forge`):

1. **auth-service** `:8081` — `./mvnw spring-boot:run -Dspring-boot.run.profiles=seed`
   (prints the random seed passwords to stdout — you'll paste one at first login)
2. **contest-api** `:8080` — `./mvnw spring-boot:run -Dspring-boot.run.profiles=seed`
   (seed makes a running "Sum of Two Numbers"/"Reverse a String" contest)
3. **orchestrator worker** — `./mvnw spring-boot:run`
4. **realtime** `:8083` — `./mvnw spring-boot:run` (Day 10)
5. **frontend** `:5173` — `npm run dev`

Over Remote-SSH you only need to forward **5173**: Vite proxies `/auth`, `/api`, `/ws` onward to the
services on `forge`'s own localhost, so those ports never leave the box.

---

## 3. The backend change — GET /api/contest

The frontend needs to know **which contest is live** (its id names the WebSocket channel
`/ws/scoreboard?contestId=…` and the standings path) and **its window** (for the countdown). No
existing student endpoint exposes that, so Day 11 adds one.

| File | What it is / does |
|---|---|
| `web/dto/ContestInfo.java` | Record returned by the endpoint: `{ id, title, startsAt, endsAt, state, serverEpochMillis }`. `serverEpochMillis` lets the client compute clock **skew** so countdowns run on the server's clock, not the student's laptop clock. |
| `web/ContestController.java` | `GET /api/contest` → the running contest via `findFirstByStateOrderByStartsAtDesc("running")`, else `NotFoundException` (404). Session-required (the existing `SessionAuthFilter` covers any non-public path). **Deliberately not** gated on `startsAt` — a student in the lobby needs the window to see a countdown *before* the contest opens; problem *content* stays gated by the existing rules. |
| `web/ContestControllerTest.java` | `@WebMvcTest(ContestController.class)` + `@MockBean ContestRepository`, same slice style as `HealthControllerTest`. Two cases: 200 with the running contest's fields, and 404 when nothing is running. The `@RestControllerAdvice` that maps `NotFoundException → 404` is loaded by the slice, so the 404 case is real. |

No migrations, no new dependencies, no changes to Day-9 scoring or the Day-10 broadcast code.

---

## 4. The rewiring — your files.zip WIP → CodEZ contract

Your `files.zip` (login.tsx, ide.tsx, code-editor.tsx, vite.config.ts) was **built against a
different backend**: the IIITB "Software Production Engineering" Go service (`:8082`, token auth,
LeetCode-style function judging). The **visual design is kept 1:1** — same card, brand mark,
terminal strip, palette, editor chrome. Only the data layer changed. What moved:

| Concern | files.zip (Go backend) | CodEZ (this build) |
|---|---|---|
| Auth transport | `POST /api/login` → `{ success, token }`, token in `localStorage['student-auth']` | `POST /auth/login` → sets **HttpOnly `sid` cookie**; nothing in localStorage; app gates on `GET /auth/me` |
| Identity field | `username` | `loginId` |
| First login | (none) | seeded accounts are `mustChangePassword` → forced **change-password** screen; contest-api 403s protected paths until cleared |
| Submit | `POST /api/submit` `{ source_code, language, test_cases[], problem_id }` (client sends tests) | `POST /api/submissions` `{ problemId, language, sourceCode }` → **202** `{ submissionId, status:"queued" }`; **hidden tests run server-side**, client never sends tests |
| Result | poll `GET /api/status/{id}` only | **WebSocket** verdict push (fast path) **+** `GET /api/submissions/{id}` poll every 2 s as fallback |
| Verdicts | free-text ("Compilation Error") + `Main.java:(\d+)` line highlight | enum `AC/WA/TLE/MLE/RE/CE/IE`; status reports `failedTest/execTimeMs/memoryKb` (no compiler text, so the CE line-highlight was dropped) |
| Languages | java-centric (`Solution` class) | `c, cpp, java, python`; **stdin/stdout** templates (Judge0 diffs stdout vs hidden tests — a `twoSum(...)` stub would WA/CE) |
| Test-case tab | editable, saved to localStorage | **read-only Samples** tab from `problem.samples` |
| Run vs Submit | two buttons | one **Submit** |
| Dev networking | proxy `/api → :8082` only | proxy `/auth → :8081`, `/api → :8080`, `/ws → :8083` (WebSocket) |

---

## 5. Frontend files — what each one does

### Config

| File | What it does |
|---|---|
| `vite.config.ts` | Three-target dev proxy (`/auth`→8081, `/api`→8080, `/ws`→8083 with `ws:true`), overridable via `VITE_AUTH_ORIGIN` / `VITE_API_ORIGIN` / `VITE_WS_ORIGIN`. `@`→`src` alias via `fileURLToPath` (ESM-correct; `__dirname` doesn't exist in an ESM config). Tailwind plugin. host:true, port 5173. |
| `tsconfig.app.json` | Your config verbatim **plus** `paths: { "@/*": ["./src/*"] }` for the alias. No `baseUrl` (deprecated in TS 6; under bundler resolution paths resolve relative to the config). |
| `index.html` | Title → `CodEZ`. |
| `src/index.css` | Tailwind v4 `@import` + `@theme` design tokens. The token **names** are exactly what your components already use (`bg-background`, `bg-card`, `border-border`, `text-muted-foreground`, `bg-accent`/`text-accent-foreground`, `bg-secondary`, `bg-input`, `text-destructive`), so your utility classes work unchanged. Dark terminal palette; one `.hljs{background:transparent}` fix so atom-one-dark doesn't paint its own panel color over the card. |

### Data layer (`src/lib`)

| File | What it does |
|---|---|
| `api.ts` | The single network module. `API_BASE=''` (relative paths → same-origin → cookie flows first-party). Typed `api.*` for every endpoint (auth, contest, problems, submissions, standings). Every DTO interface **mirrors a Java record** and is commented with the record name — keep them in lockstep. `ApiError{status,code,message}` (handlers branch on `status`). `LANGUAGES`/`Language` mirror the server's allowed set. |
| `format.ts` | Verdict metadata (label + color tone per `AC/WA/…`), `fmtClock` (ms→`h:mm:ss`), `fmtTime`/`fmtDateTime`. |
| `boilerplate.ts` | Per-language **stdin/stdout** starter code. (Java's public class is `Main` — the orchestrator compiles `Main.java`.) |
| `session.tsx` | `SessionProvider`/`useSession`. `GET /auth/me` on mount (401→anonymous, survives reload). `login()` returns the `Me` so callers can route on `mustChangePassword`. `logout()`, `refresh()`. |
| `contest.tsx` | `ContestProvider`/`useContest`. Loads `GET /api/contest`; computes **skew** = `serverEpochMillis − Date.now()`; exposes `now()` = server-corrected time; `error:'none'` on 404. |
| `socket.ts` | `ScoreboardSocket` — one reconnecting WebSocket to `/ws/scoreboard?contestId=N`. Parses the `{type,data}` envelope into `onStandings`/`onVerdict`; `onStatus` for the live dot. Exponential backoff (1 s → 10 s cap), 30 s `ping` keepalive, `close()` stops cleanly. |
| `realtime.tsx` | `RealtimeProvider`/`useRealtime`. Owns exactly **one** socket per `contest.id`. Holds the latest standings; fans verdict frames to subscribers via `onVerdict(fn)→unsubscribe`. Surfaces socket `status`. |

### Components (`src/components`)

| File | What it does |
|---|---|
| `ui/button.tsx` | Minimal shadcn-compatible `Button` (variants default/outline/ghost) your components import. |
| `login.tsx` | Your login card, rewired: `loginId` field, `api.login`, cookie session, status-based errors (401/403/400/network). Demo-account button → a hint (CodEZ logins are admin-issued). `onLogin(me)` routes onward. |
| `change-password.tsx` | Forced first-login change, same card language. Client mirrors the server's `@Size(min=8)`; `POST /auth/change-password` (204) flips the flag on the same session. |
| `top-bar.tsx` | Brand, nav (Problems / Standings / My submissions), the **Countdown** chip, a **socket-status dot** (green pulse=live, amber=connecting, red=polling), user + role + logout. |
| `countdown.tsx` | 1 s tick against `now()`: amber "starts in", green "… left", dim "contest over". |
| `verdict-badge.tsx` | Colored verdict chip (AC green, WA/RE red, TLE/MLE/CE amber, IE dim). |
| `problem-panel.tsx` | Left pane of the IDE (your `ide.tsx` imported `./problem-panel`, which the zip didn't include — this is it). Label+title, limits, `statementMd` (pre-wrap prose for now), samples with copy. |
| `code-editor.tsx` | Your custom editor (textarea + hljs overlay, draggable gutter, font menu, fullscreen, Tab/Enter) adapted: 4 languages, read-only Samples tab, **one Submit** → `api.submit` (202) → verdict via the WebSocket fast path **and** a 2 s status poll (whichever fires; poll result is authoritative). Cooldown countdown on 429; 409/413/403/400 handled. hljs core build with only c/cpp/java/python registered. |
| `ide.tsx` | Your split-pane (draggable divider) rewired: `api.problem(id)` → real `ProblemDetail`; owns code+language; persists per problem under `codez-code:{pid}:{lang}` (the zip's single global key bled work across problems); seeds the template when empty; 403→"not open yet", 404→"not found". |
| `problems.tsx` | Card grid → `/problems/{id}`. 403 → lobby with a big countdown; 404 → "no contest" panel. |
| `standings.tsx` | The live ICPC board. Primary source = the WebSocket standings; when the socket isn't open, falls back to `GET …/standings` every 5 s (contest-api micro-caches ~2 s). LIVE/POLLING pill; your-rank chip; cells per contract (solved=green `+attempts`/AC-minute, attempted=red `-attempts`, none=dim dot); highlights your row. |
| `submissions.tsx` | Your submissions (`/mine`, owner-scoped). Auto-refreshes on verdict frames; problem-id→label via best-effort `GET /api/problems`. |
| `toasts.tsx` | Bottom-right verdict toasts fed by `onVerdict` (per-user frames), 4 s auto-dismiss. |
| `shell.tsx` | Authed layout + gate: loading splash → `!me`→/login → `mustChange`→/change-password. Then mounts `ContestProvider`→`RealtimeProvider` around TopBar + `<Outlet/>` + Toasts, so the whole app shares one contest lookup and one socket. |
| `App.tsx` | Router + `SessionProvider`. `/login` and `/change-password` render full-screen (outside the shell); `/problems`, `/problems/:id`, `/standings`, `/submissions` render inside `Shell`; `*`→`/problems`. |

**Left unchanged** from your scaffold: `main.tsx`, `eslint.config.js`, `tsconfig.json`,
`tsconfig.node.json`, `README.md`, `public/`, `src/assets/`, `.gitignore`, and `frontend/files.zip`
(your WIP archive — kept as-is). `src/App.css` is now unused but harmless; delete it whenever.

---

## 6. Why the dev proxy (and not CORS)

All app code uses **relative** paths (`API_BASE=''`), and Vite forwards them to the services. That
keeps every request **same-origin from the browser's view**, which matters because: the `sid` cookie
is HttpOnly and only sent first-party; the services don't emit CORS headers; and CORS is
port-sensitive (`:5173` ≠ `:8080`). Proxying sidesteps all of it, and the same relative paths will
work behind a real reverse proxy in production with no code change.

---

## 7. End-to-end check

1. `npm run dev`, open `:5173` → redirected to **/login**.
2. Sign in with `stud001` + its seeded password → forced **/change-password** → set an 8+ char
   password → land on **/problems**.
3. Open problem **A**, pick a language (template loads), **Submit** → button shows "Judging…" →
   within ~1 s a **verdict toast** + the Result tab fills (verdict, time, memory).
4. Open **/standings** in a second browser (log in as `stud002`). Submit an AC as stud001 →
   stud002's board row updates **live** (top bar dot green, pill LIVE).
5. Kill the **realtime** service → pill flips to **POLLING**, board still updates every 5 s →
   restart realtime → back to **LIVE**, socket auto-reconnects.

**Exit criteria:** login + forced change work; problems gate correctly (403 lobby / 404 empty);
a submission returns 202 and its verdict arrives live with a poll fallback; the board is live with a
working polling fallback; `npm run build` stays green.

---

## 8. Known gaps / next

- `statementMd` renders as pre-wrapped text, not full Markdown. Upgrade path: add `react-markdown`
  in `problem-panel.tsx` (isolated change).
- **Admin panel = Day 12** (your roadmap's Day-11 card): problem/test-case/timing editors, rejudge,
  announcements, and **user management + CSV roster import**.
- Day-3 auth hardening (login throttle/lockout + auth event log) is still pending from the backlog.
- Day-7 submission-endpoint `.http` tests remain deferred.
