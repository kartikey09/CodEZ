import { useState } from 'react';
import { Clock, MemoryStick, Copy, Check } from 'lucide-react';
import type { ProblemDetail } from '@/lib/api';

/*
 * Left pane of the IDE (ide.tsx imports './problem-panel', which files.zip
 * referenced but didn't include — this is the CodEZ version). Renders the
 * ProblemDetail record: label + title, judge limits, the markdown statement
 * (whitespace-preserving prose for now — a full renderer is a later polish),
 * and the sample tests with copy buttons. Hidden tests never leave the server;
 * samples are exactly what GET /api/problems/{id} exposes.
 */

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => {
        void navigator.clipboard.writeText(text).then(() => {
          setCopied(true);
          setTimeout(() => setCopied(false), 1200);
        });
      }}
      className="text-muted-foreground hover:text-foreground transition-colors p-1"
      title="Copy"
      aria-label="Copy"
    >
      {copied ? <Check size={13} className="text-accent" /> : <Copy size={13} />}
    </button>
  );
}

export function ProblemPanel({ problem }: { problem: ProblemDetail }) {
  return (
    <div className="h-full overflow-y-auto bg-card border border-border rounded-lg">
      <div className="px-6 pt-6 pb-4 border-b border-border/50">
        <div className="flex items-center gap-3">
          <span className="w-8 h-8 rounded-md bg-accent/15 border border-accent/30 text-accent font-mono font-bold text-sm flex items-center justify-center">
            {problem.label}
          </span>
          <h1 className="text-lg font-bold text-white">{problem.title}</h1>
        </div>
        <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground font-mono">
          <span className="inline-flex items-center gap-1.5">
            <Clock size={13} /> {problem.timeLimitMs} ms
          </span>
          <span className="inline-flex items-center gap-1.5">
            <MemoryStick size={13} /> {problem.memoryLimitMb} MB
          </span>
        </div>
      </div>

      <div className="px-6 py-5">
        <div className="text-sm leading-7 whitespace-pre-wrap">{problem.statementMd}</div>
      </div>

      {problem.samples.length > 0 && (
        <div className="px-6 pb-6">
          <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
            Sample tests
          </h2>
          <div className="flex flex-col gap-4">
            {problem.samples.map((s) => (
              <div key={s.ordinal} className="grid grid-cols-2 gap-3">
                <div className="rounded-md border border-border bg-input overflow-hidden">
                  <div className="flex items-center justify-between px-3 py-1.5 border-b border-border/60 text-[11px] font-mono text-muted-foreground">
                    <span>Input {s.ordinal}</span>
                    <CopyButton text={s.input} />
                  </div>
                  <pre className="px-3 py-2 font-mono text-xs whitespace-pre-wrap">{s.input}</pre>
                </div>
                <div className="rounded-md border border-border bg-input overflow-hidden">
                  <div className="flex items-center justify-between px-3 py-1.5 border-b border-border/60 text-[11px] font-mono text-muted-foreground">
                    <span>Expected {s.ordinal}</span>
                    <CopyButton text={s.expectedOutput} />
                  </div>
                  <pre className="px-3 py-2 font-mono text-xs whitespace-pre-wrap">
                    {s.expectedOutput}
                  </pre>
                </div>
              </div>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-4">
            Your program reads stdin and writes stdout. The judge runs these samples plus hidden
            tests.
          </p>
        </div>
      )}
    </div>
  );
}
