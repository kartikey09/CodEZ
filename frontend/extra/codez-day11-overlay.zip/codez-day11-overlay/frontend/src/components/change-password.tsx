import { useState } from 'react';
import type { FormEvent } from 'react';
import { Button } from '@/components/ui/button';
import { KeyRound, Loader2, Terminal, AlertCircle } from 'lucide-react';
import { api, ApiError } from '@/lib/api';
import { useSession } from '@/lib/session';

/*
 * Seeded accounts carry mustChangePassword=true, and contest-api's SessionAuthFilter
 * answers 403 PASSWORD_CHANGE_REQUIRED on every protected path until it's cleared —
 * so this screen is a hard gate after first sign-in, in the same card language as
 * the login. POST /auth/change-password flips the flag on the *same* session (no
 * re-login needed); the ≥8-char check mirrors the server's @Size(min = 8) so the
 * common case fails fast client-side, while the server stays the authority.
 */

interface ChangePasswordProps {
  onDone: () => void;
}

export function ChangePassword({ onDone }: ChangePasswordProps) {
  const { me } = useSession();
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setError(null);

    if (!current || !next || !confirm) {
      setError('Fill in all three fields.');
      return;
    }
    if (next.length < 8) {
      setError('The new password must be at least 8 characters.');
      return;
    }
    if (next !== confirm) {
      setError('New password and confirmation do not match.');
      return;
    }

    setLoading(true);
    try {
      await api.changePassword(current, next);
      onDone();
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err.message || 'Password change failed.');
      } else {
        setError('Cannot reach the server. Are the CodEZ services running?');
      }
    } finally {
      setLoading(false);
    }
  };

  const field = (
    id: string,
    label: string,
    value: string,
    setValue: (v: string) => void,
    autoComplete: string,
  ) => (
    <div className="flex flex-col gap-1.5">
      <label
        htmlFor={id}
        className="text-xs font-semibold text-muted-foreground uppercase tracking-wider"
      >
        {label}
      </label>
      <input
        id={id}
        type="password"
        autoComplete={autoComplete}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="••••••••"
        className="h-10 px-3 rounded-md bg-input border border-border text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-accent focus:ring-2 focus:ring-accent/30 transition-colors"
      />
    </div>
  );

  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center px-4 py-10 font-sans">
      <div className="w-full max-w-sm">
        <div className="flex items-center gap-2.5 mb-8 justify-center">
          <div className="w-9 h-9 bg-accent rounded-md flex items-center justify-center">
            <KeyRound size={16} className="text-accent-foreground" />
          </div>
          <span className="text-xl font-bold tracking-tight">CodEZ</span>
        </div>

        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="px-7 pt-7 pb-1">
            <h1 className="text-lg font-bold text-white">Set a new password</h1>
            <p className="text-sm text-muted-foreground mt-1">
              {me ? `Signed in as ${me.displayName}. ` : ''}
              The issued password is one-time — pick your own to continue.
            </p>
          </div>

          <form onSubmit={submit} className="px-7 py-6 flex flex-col gap-4">
            {field('current', 'Current password', current, setCurrent, 'current-password')}
            {field('next', 'New password (min 8 chars)', next, setNext, 'new-password')}
            {field('confirm', 'Confirm new password', confirm, setConfirm, 'new-password')}

            {error && (
              <div
                role="alert"
                aria-live="polite"
                className="flex items-start gap-2 text-sm text-destructive bg-destructive/10 border border-destructive/30 rounded-md px-3 py-2"
              >
                <AlertCircle size={16} className="mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <Button type="submit" disabled={loading} className="h-10 mt-1 font-semibold">
              {loading ? (
                <>
                  <Loader2 size={16} className="animate-spin motion-reduce:animate-none" />
                  Saving…
                </>
              ) : (
                'Save and continue'
              )}
            </Button>
          </form>

          <div className="border-t border-border bg-secondary/30 px-7 py-3 flex items-center gap-2 font-mono text-xs text-muted-foreground">
            <Terminal size={13} className="text-accent" />
            <span>passwd student</span>
            <span
              className="w-1.5 h-3.5 bg-accent inline-block animate-pulse motion-reduce:animate-none"
              aria-hidden="true"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
