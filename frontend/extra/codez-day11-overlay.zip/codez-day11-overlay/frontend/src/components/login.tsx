import { useState } from 'react';
import type { FormEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Eye, EyeOff, Loader2, Terminal, AlertCircle } from 'lucide-react';
import { ApiError } from '@/lib/api';
import type { Me } from '@/lib/api';
import { useSession } from '@/lib/session';

/*
 * The files.zip login card, rewired from the Go token contract to CodEZ:
 *   - field is loginId (auth-service LoginRequest), not username
 *   - POST /auth/login sets the HttpOnly sid cookie server-side — nothing is
 *     written to localStorage, and the app gates on /auth/me, not a stored token
 *   - errors branch on status: 401 bad credentials, 403 disabled account,
 *     400 validation; network failure gets its own message
 *   - no shared demo account: CodEZ accounts are admin-issued with random
 *     seeded passwords, so the demo button became a hint line
 * onLogin receives the Me so the caller can route straight to the forced
 * password change when mustChangePassword is true.
 */

interface LoginProps {
  onLogin: (me: Me) => void;
}

export function Login({ onLogin }: LoginProps) {
  const { login } = useSession();
  const [loginId, setLoginId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setError(null);

    if (!loginId.trim() || !password) {
      setError('Enter your login id and password.');
      return;
    }

    setLoading(true);
    try {
      const me = await login(loginId.trim(), password);
      onLogin(me);
    } catch (err) {
      if (err instanceof ApiError) {
        if (err.status === 401) setError('Invalid login id or password.');
        else if (err.status === 403) setError('This account is disabled. Ask the contest admin.');
        else setError(err.message || 'Sign-in failed.');
      } else {
        setError('Cannot reach the server. Are the CodEZ services running?');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center px-4 py-10 font-sans">
      <div className="w-full max-w-sm">
        {/* Brand */}
        <div className="flex items-center gap-2.5 mb-8 justify-center">
          <div className="w-9 h-9 bg-accent rounded-md flex items-center justify-center">
            <span className="text-accent-foreground font-mono font-bold text-sm">{'</>'}</span>
          </div>
          <span className="text-xl font-bold tracking-tight">CodEZ</span>
        </div>

        {/* Card */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="px-7 pt-7 pb-1">
            <h1 className="text-lg font-bold text-white">Sign in</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Access the judge to solve and submit problems.
            </p>
          </div>

          <form onSubmit={submit} className="px-7 py-6 flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="loginId"
                className="text-xs font-semibold text-muted-foreground uppercase tracking-wider"
              >
                Login id
              </label>
              <input
                id="loginId"
                type="text"
                autoComplete="username"
                autoFocus
                value={loginId}
                onChange={(e) => setLoginId(e.target.value)}
                placeholder="stud001"
                className="h-10 px-3 rounded-md bg-input border border-border text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-accent focus:ring-2 focus:ring-accent/30 transition-colors"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="password"
                className="text-xs font-semibold text-muted-foreground uppercase tracking-wider"
              >
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="h-10 w-full pl-3 pr-10 rounded-md bg-input border border-border text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-accent focus:ring-2 focus:ring-accent/30 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((s) => !s)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-1"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {error && (
              <div
                role="alert"
                aria-live="polite"
                className="flex items-start gap-2 text-sm text-destructive bg-destructive/10 border border-destructive/30 rounded-md px-3 py-2"
              >
                <AlertCircle size={16} className="mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <Button type="submit" disabled={loading} className="h-10 mt-1 font-semibold">
              {loading ? (
                <>
                  <Loader2 size={16} className="animate-spin motion-reduce:animate-none" />
                  Signing in…
                </>
              ) : (
                'Sign in'
              )}
            </Button>

            <p className="text-xs text-muted-foreground text-center">
              Accounts are issued by the contest admin. Your first sign-in will ask you to set a
              new password.
            </p>
          </form>

          {/* Signature: a terminal strip — this is a judge for coders */}
          <div className="border-t border-border bg-secondary/30 px-7 py-3 flex items-center gap-2 font-mono text-xs text-muted-foreground">
            <Terminal size={13} className="text-accent" />
            <span>student@codez:~$</span>
            <span
              className="w-1.5 h-3.5 bg-accent inline-block animate-pulse motion-reduce:animate-none"
              aria-hidden="true"
            />
          </div>
        </div>

        <p className="text-center text-xs text-muted-foreground/70 mt-6">
          IIIT-B · timed contests, judged live
        </p>
      </div>
    </div>
  );
}
