import type { ButtonHTMLAttributes } from 'react';

/*
 * Minimal stand-in for the shadcn/ui Button that login.tsx and code-editor.tsx
 * import from '@/components/ui/button'. Same call shape (variant + className +
 * native button props), no cva/tailwind-merge dependency — callers pick a variant
 * instead of stacking conflicting color utilities.
 */

const base =
  'inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ' +
  'h-9 px-4 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 ' +
  'disabled:pointer-events-none disabled:opacity-50';

const variants = {
  default: 'bg-accent text-accent-foreground hover:bg-accent/90',
  outline: 'border border-border bg-secondary/30 text-foreground hover:bg-secondary',
  ghost: 'text-muted-foreground hover:text-foreground hover:bg-secondary/60',
} as const;

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: keyof typeof variants;
}

export function Button({ variant = 'default', className, ...props }: ButtonProps) {
  return (
    <button
      className={[base, variants[variant], className].filter(Boolean).join(' ')}
      {...props}
    />
  );
}
