import { useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { Loader2, Radio, RefreshCw } from 'lucide-react';
import { api } from '@/lib/api';
import type { MyStanding, Standings as StandingsData } from '@/lib/api';
import { useContest } from '@/lib/contest';
import { useRealtime } from '@/lib/realtime';
import { useSession } from '@/lib/session';
import { fmtTime } from '@/lib/format';

/*
 * The live ICPC scoreboard. Primary source is the WebSocket: RealtimeProvider holds
 * the latest StandingsResponse the realtime service pushed. When the socket isn't
 * open (status !== 'open') this falls back to REST polling GET /api/contests/{id}/standings
 * every 5 s — the roadmap's documented fallback; contest-api micro-caches the board
 * ~2 s so the poll is cheap. A pill shows which mode is live.
 *
 * Cells follow the Cell contract: state "solved" -> green with attempt count and the
 * AC minute; "attempted" -> red with a negative attempt count; "none" -> a dim dot.
 * The current user's row is highlighted, and a chip up top shows their rank (from the
 * board if present, else GET /standings/me).
 */

const POLL_MS = 5000;

export function Standings() {
  const { contest } = useContest();
  const { standings: liveBoard, status } = useRealtime();
  const { me } = useSession();

  const [polledBoard, setPolledBoard] = useState<StandingsData | null>(null);
  const [mine, setMine] = useState<MyStanding | null>(null);
  const [initialLoading, setInitialLoading] = useState(true);

  const socketLive = status === 'open';
  const board = socketLive ? liveBoard : (polledBoard ?? liveBoard);

  // REST fallback when the socket isn't carrying the board.
  useEffect(() => {
    if (contest == null || socketLive) return;
    let alive = true;
    const tick = () => {
      api
        .standings(contest.id)
        .then((b) => {
          if (alive) setPolledBoard(b);
        })
        .catch(() => {})
        .finally(() => {
          if (alive) setInitialLoading(false);
        });
    };
    tick();
    const t = setInterval(tick, POLL_MS);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [contest?.id, socketLive]);

  useEffect(() => {
    if (board) setInitialLoading(false);
  }, [board]);

  // My rank: prefer the row already in the board, else ask the server.
  const myRow = useMemo(
    () => (me && board ? board.rows.find((r) => r.userId === me.userId) ?? null : null),
    [me, board],
  );
  useEffect(() => {
    if (contest == null || !me || myRow) return;
    let alive = true;
    api
      .myStanding(contest.id)
      .then((m) => {
        if (alive) setMine(m);
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [contest?.id, me, myRow]);

  const myRank = myRow?.rank ?? mine?.rank ?? null;
  const mySolved = myRow?.solved ?? mine?.solved ?? 0;

  if (contest == null) {
    return <Centered>No contest is running right now.</Centered>;
  }
  if (initialLoading && !board) {
    return (
      <Centered>
        <Loader2 size={16} className="animate-spin motion-reduce:animate-none" /> Loading standings…
      </Centered>
    );
  }
  if (!board) {
    return <Centered>Standings aren't available yet.</Centered>;
  }

  return (
    <div className="max-w-5xl mx-auto py-6 px-4">
      <div className="flex items-center gap-3 mb-4">
        <h1 className="text-xl font-bold text-white">{contest.title}</h1>
        <span
          className={`inline-flex items-center gap-1.5 rounded border px-2 py-0.5 text-xs font-mono ${
            socketLive
              ? 'text-accent border-accent/30 bg-accent/10'
              : 'text-amber-400 border-amber-400/30 bg-amber-400/10'
          }`}
          title={socketLive ? 'Updating live over WebSocket' : 'WebSocket down — polling every 5s'}
        >
          {socketLive ? <Radio size={12} /> : <RefreshCw size={12} />}
          {socketLive ? 'LIVE' : 'POLLING'}
        </span>
        {myRank != null && (
          <span className="ml-auto text-sm text-muted-foreground">
            You: <span className="text-foreground font-semibold">#{myRank}</span> · {mySolved} solved
          </span>
        )}
      </div>

      <div className="overflow-x-auto rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-secondary/40 text-muted-foreground">
              <th className="text-left font-medium px-3 py-2.5 w-12">#</th>
              <th className="text-left font-medium px-3 py-2.5">Contestant</th>
              <th className="text-center font-medium px-3 py-2.5 w-16">Solved</th>
              <th className="text-center font-medium px-3 py-2.5 w-20">Penalty</th>
              {board.problems.map((label) => (
                <th key={label} className="text-center font-medium px-2 py-2.5 w-16 font-mono">
                  {label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {board.rows.map((row) => {
              const isMe = me && row.userId === me.userId;
              return (
                <tr
                  key={row.userId}
                  className={`border-t border-border/60 ${
                    isMe ? 'bg-accent/10' : 'hover:bg-secondary/20'
                  }`}
                >
                  <td className="px-3 py-2.5 font-mono text-muted-foreground">{row.rank}</td>
                  <td className="px-3 py-2.5">
                    <span className={isMe ? 'text-accent font-semibold' : 'text-foreground'}>
                      {row.displayName}
                    </span>
                  </td>
                  <td className="px-3 py-2.5 text-center font-semibold">{row.solved}</td>
                  <td className="px-3 py-2.5 text-center font-mono text-muted-foreground">
                    {row.penalty}
                  </td>
                  {row.cells.map((cell) => (
                    <td key={cell.label} className="px-2 py-2.5 text-center">
                      <Cell cell={cell} />
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <p className="text-xs text-muted-foreground mt-3">
        Ranked by problems solved, then total penalty. Updated {fmtTime(board.generatedAt)}.
      </p>
    </div>
  );
}

function Cell({ cell }: { cell: { state: string; attempts: number; acMinute: number | null } }) {
  if (cell.state === 'solved') {
    return (
      <div className="inline-flex flex-col leading-tight">
        <span className="text-accent font-mono font-semibold">
          +{cell.attempts > 0 ? cell.attempts : ''}
        </span>
        {cell.acMinute != null && (
          <span className="text-[10px] text-muted-foreground font-mono">{cell.acMinute}</span>
        )}
      </div>
    );
  }
  if (cell.state === 'attempted') {
    return <span className="text-destructive font-mono">-{cell.attempts}</span>;
  }
  return <span className="text-muted-foreground/40">·</span>;
}

function Centered({ children }: { children: ReactNode }) {
  return (
    <div className="h-full flex items-center justify-center gap-2 text-sm text-muted-foreground">
      {children}
    </div>
  );
}
