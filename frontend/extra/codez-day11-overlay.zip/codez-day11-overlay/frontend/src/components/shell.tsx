import { Navigate, Outlet } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { useSession } from '@/lib/session';
import { ContestProvider } from '@/lib/contest';
import { RealtimeProvider } from '@/lib/realtime';
import { TopBar } from './top-bar';
import { Toasts } from './toasts';

/*
 * Layout + gate for every signed-in page. Order matters:
 *   - still resolving /auth/me  -> a splash (avoids a flash of the login screen)
 *   - no session                -> /login
 *   - session but mustChangePassword -> /change-password (contest-api 403s every
 *     protected path until it's cleared, so there's nothing useful to show anyway)
 * Once past the gate, the contest + realtime providers wrap the app so the top bar,
 * standings, editor and toasts all share one contest lookup and one WebSocket.
 */

export function Shell() {
  const { me, loading } = useSession();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-muted-foreground gap-2">
        <Loader2 size={18} className="animate-spin motion-reduce:animate-none" />
        Loading…
      </div>
    );
  }

  if (!me) return <Navigate to="/login" replace />;
  if (me.mustChangePassword) return <Navigate to="/change-password" replace />;

  return (
    <ContestProvider>
      <RealtimeProvider>
        <div className="min-h-screen flex flex-col">
          <TopBar />
          <main className="flex-1 overflow-hidden">
            <Outlet />
          </main>
          <Toasts />
        </div>
      </RealtimeProvider>
    </ContestProvider>
  );
}
