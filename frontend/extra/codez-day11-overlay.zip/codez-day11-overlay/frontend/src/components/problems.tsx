import { useEffect, useState } from 'react';
import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Loader2, CalendarClock, Inbox } from 'lucide-react';
import { api, ApiError } from '@/lib/api';
import type { ProblemSummary } from '@/lib/api';
import { useContest } from '@/lib/contest';
import { Countdown } from './countdown';

/*
 * Problem list. contest-api gates GET /api/problems: 403 before the contest starts,
 * 404 when there is no running contest. So:
 *   - 403  -> lobby: a big countdown to the start (the window is known via the
 *             ContestProvider even while problems are still locked)
 *   - 404  -> "no contest" panel
 * Otherwise a card grid; each card routes to /problems/{id} (the IDE).
 */

export function Problems() {
  const { contest, now } = useContest();
  const [problems, setProblems] = useState<ProblemSummary[] | null>(null);
  const [state, setState] = useState<'loading' | 'ready' | 'locked' | 'none' | 'error'>('loading');

  useEffect(() => {
    let alive = true;
    setState('loading');
    api
      .problems()
      .then((ps) => {
        if (!alive) return;
        setProblems(ps);
        setState('ready');
      })
      .catch((err) => {
        if (!alive) return;
        if (err instanceof ApiError && err.status === 403) setState('locked');
        else if (err instanceof ApiError && err.status === 404) setState('none');
        else setState('error');
      });
    return () => {
      alive = false;
    };
  }, [contest?.id]);

  if (state === 'loading') {
    return (
      <Centered>
        <Loader2 size={16} className="animate-spin motion-reduce:animate-none" /> Loading problems…
      </Centered>
    );
  }

  if (state === 'locked') {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center">
          <CalendarClock size={26} className="text-amber-400 mx-auto mb-3" />
          <h2 className="text-xl font-bold text-white mb-1">{contest?.title ?? 'Contest'}</h2>
          <p className="text-sm text-muted-foreground mb-4">
            Problems unlock when the contest begins.
          </p>
          {contest && (
            <div className="scale-125 inline-block">
              <Countdown contest={contest} now={now} />
            </div>
          )}
        </div>
      </div>
    );
  }

  if (state === 'none') {
    return (
      <Centered>
        <Inbox size={18} className="text-muted-foreground" /> No contest is running right now.
      </Centered>
    );
  }

  if (state === 'error' || !problems) {
    return <Centered>Couldn't load problems. Try again shortly.</Centered>;
  }

  return (
    <div className="max-w-3xl mx-auto py-8 px-4">
      <div className="flex items-baseline justify-between mb-5">
        <h1 className="text-xl font-bold text-white">{contest?.title ?? 'Problems'}</h1>
        <span className="text-sm text-muted-foreground">
          {problems.length} problem{problems.length === 1 ? '' : 's'}
        </span>
      </div>

      {problems.length === 0 ? (
        <Centered>No problems have been published yet.</Centered>
      ) : (
        <div className="flex flex-col gap-2">
          {problems.map((p) => (
            <Link
              key={p.id}
              to={`/problems/${p.id}`}
              className="group flex items-center gap-4 rounded-lg border border-border bg-card px-4 py-3.5 hover:border-accent/40 hover:bg-secondary/30 transition-colors"
            >
              <span className="w-9 h-9 rounded-md bg-accent/15 border border-accent/30 text-accent font-mono font-bold flex items-center justify-center shrink-0">
                {p.label}
              </span>
              <span className="text-foreground font-medium flex-1">{p.title}</span>
              <ChevronRight
                size={18}
                className="text-muted-foreground group-hover:text-accent transition-colors"
              />
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

function Centered({ children }: { children: ReactNode }) {
  return (
    <div className="h-full flex items-center justify-center gap-2 text-sm text-muted-foreground">
      {children}
    </div>
  );
}
