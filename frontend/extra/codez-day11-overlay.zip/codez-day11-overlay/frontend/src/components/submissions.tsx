import { useCallback, useEffect, useState } from 'react';
import type { ReactNode } from 'react';
import { Loader2, RefreshCw, Inbox } from 'lucide-react';
import { api } from '@/lib/api';
import type { ProblemSummary, SubmissionSummary } from '@/lib/api';
import { Button } from '@/components/ui/button';
import { useRealtime } from '@/lib/realtime';
import { VerdictBadge } from './verdict-badge';
import { fmtDateTime } from '@/lib/format';

/*
 * My submissions (GET /api/submissions/mine — owner-scoped by the session, a student
 * only ever sees their own). The table auto-refreshes when a verdict frame arrives on
 * the WebSocket, so a row flips from "running" to its verdict without a manual reload,
 * plus a refresh button. Problem ids are mapped to labels via a best-effort
 * GET /api/problems (skipped silently if the contest is between states).
 */

export function Submissions() {
  const { onVerdict } = useRealtime();
  const [rows, setRows] = useState<SubmissionSummary[] | null>(null);
  const [labels, setLabels] = useState<Record<number, string>>({});
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async (initial = false) => {
    if (initial) setLoading(true);
    else setRefreshing(true);
    try {
      const mine = await api.mySubmissions();
      setRows(mine);
    } catch {
      /* leave the last-known rows on a transient failure */
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    void load(true);
    // label map is best-effort; a 403/404 here just means no labels
    api
      .problems()
      .then((ps: ProblemSummary[]) =>
        setLabels(Object.fromEntries(ps.map((p) => [p.id, p.label]))),
      )
      .catch(() => {});
  }, [load]);

  // Any verdict frame likely changes one of these rows — refresh.
  useEffect(() => onVerdict(() => void load(false)), [onVerdict, load]);

  if (loading) {
    return (
      <Centered>
        <Loader2 size={16} className="animate-spin motion-reduce:animate-none" /> Loading
        submissions…
      </Centered>
    );
  }
  if (!rows) {
    return <Centered>Couldn't load your submissions.</Centered>;
  }

  return (
    <div className="max-w-3xl mx-auto py-6 px-4">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-bold text-white">My submissions</h1>
        <Button variant="outline" onClick={() => void load(false)} disabled={refreshing}>
          <RefreshCw
            size={14}
            className={refreshing ? 'animate-spin motion-reduce:animate-none' : undefined}
          />
          Refresh
        </Button>
      </div>

      {rows.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-2">
          <Inbox size={22} />
          <p className="text-sm">No submissions yet. Solve a problem and hit Submit.</p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-border">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-secondary/40 text-muted-foreground">
                <th className="text-left font-medium px-3 py-2.5 w-16">#</th>
                <th className="text-left font-medium px-3 py-2.5 w-20">Problem</th>
                <th className="text-left font-medium px-3 py-2.5 w-24">Language</th>
                <th className="text-left font-medium px-3 py-2.5 w-28">Status</th>
                <th className="text-left font-medium px-3 py-2.5">Submitted</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((s) => (
                <tr key={s.id} className="border-t border-border/60 hover:bg-secondary/20">
                  <td className="px-3 py-2.5 font-mono text-muted-foreground">{s.id}</td>
                  <td className="px-3 py-2.5 font-mono">
                    <span className="text-accent">{labels[s.problemId] ?? s.problemId}</span>
                  </td>
                  <td className="px-3 py-2.5 text-foreground">{s.language}</td>
                  <td className="px-3 py-2.5">
                    {s.status === 'done' ? (
                      <VerdictBadge verdict={s.verdict} />
                    ) : (
                      <span className="inline-flex items-center gap-1.5 text-amber-400 text-xs font-mono">
                        <Loader2 size={12} className="animate-spin motion-reduce:animate-none" />
                        {s.status}
                      </span>
                    )}
                  </td>
                  <td className="px-3 py-2.5 text-muted-foreground">{fmtDateTime(s.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function Centered({ children }: { children: ReactNode }) {
  return (
    <div className="h-full flex items-center justify-center gap-2 text-sm text-muted-foreground">
      {children}
    </div>
  );
}
