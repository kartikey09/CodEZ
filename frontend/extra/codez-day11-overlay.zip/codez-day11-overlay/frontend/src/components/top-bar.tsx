import { NavLink, useNavigate } from 'react-router-dom';
import { LogOut } from 'lucide-react';
import { useSession } from '@/lib/session';
import { useContest } from '@/lib/contest';
import { useRealtime } from '@/lib/realtime';
import { Countdown } from './countdown';

/*
 * App chrome for signed-in pages: brand mark (same as the login card), the three
 * student destinations, the contest clock, a socket-status dot (green pulse = live
 * WebSocket, amber = connecting, red = closed and pages are on REST fallback),
 * and who's signed in + logout.
 */

const DOT: Record<string, { cls: string; title: string }> = {
  open: { cls: 'bg-accent animate-pulse', title: 'Live — WebSocket connected' },
  connecting: { cls: 'bg-amber-400', title: 'Connecting…' },
  closed: { cls: 'bg-destructive', title: 'Offline — polling fallback' },
};

export function TopBar() {
  const { me, logout } = useSession();
  const { contest, now } = useContest();
  const { status } = useRealtime();
  const navigate = useNavigate();

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `px-3 py-1.5 rounded-md text-sm transition-colors ${
      isActive ? 'bg-secondary text-white' : 'text-muted-foreground hover:text-foreground'
    }`;

  const dot = DOT[status] ?? DOT.closed;

  return (
    <header className="h-14 border-b border-border bg-card/60 backdrop-blur flex items-center px-4 gap-4 shrink-0">
      <div className="flex items-center gap-2">
        <div className="w-7 h-7 bg-accent rounded-md flex items-center justify-center">
          <span className="text-accent-foreground font-mono font-bold text-[11px]">{'</>'}</span>
        </div>
        <span className="font-bold tracking-tight">CodEZ</span>
      </div>

      <nav className="flex items-center gap-1 ml-4">
        <NavLink to="/problems" className={linkClass}>
          Problems
        </NavLink>
        <NavLink to="/standings" className={linkClass}>
          Standings
        </NavLink>
        <NavLink to="/submissions" className={linkClass}>
          My submissions
        </NavLink>
      </nav>

      <div className="ml-auto flex items-center gap-3">
        {contest && <Countdown contest={contest} now={now} />}
        <span
          className={`w-2 h-2 rounded-full ${dot.cls}`}
          title={dot.title}
          aria-label={dot.title}
        />
        {me && (
          <span className="text-sm text-muted-foreground">
            {me.displayName}
            {me.role === 'admin' && (
              <span className="ml-1.5 rounded border border-border bg-secondary px-1.5 py-0.5 font-mono text-[10px] uppercase">
                admin
              </span>
            )}
          </span>
        )}
        <button
          onClick={() => {
            void logout().finally(() => navigate('/login'));
          }}
          className="text-muted-foreground hover:text-foreground transition-colors p-1.5"
          title="Sign out"
          aria-label="Sign out"
        >
          <LogOut size={16} />
        </button>
      </div>
    </header>
  );
}
