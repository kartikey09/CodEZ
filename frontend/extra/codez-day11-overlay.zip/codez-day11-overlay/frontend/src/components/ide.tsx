import { useCallback, useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { useParams } from 'react-router-dom';
import { AlertTriangle, Lock, Loader2 } from 'lucide-react';
import { api, ApiError } from '@/lib/api';
import type { Language, ProblemDetail } from '@/lib/api';
import { LANGUAGES } from '@/lib/api';
import { BOILERPLATE } from '@/lib/boilerplate';
import { ProblemPanel } from './problem-panel';
import { CodeEditor } from './code-editor';

/*
 * The files.zip split-pane IDE, rewired to CodEZ. It:
 *   - loads GET /api/problems/{id} (a real ProblemDetail, not the Go /api/problem?id=)
 *   - owns code + language and persists them per problem+language under
 *     codez-code:{problemId}:{lang} (files.zip used one global 'saved-code' key,
 *     which bled one problem's work into the next); seeds the stdin/stdout
 *     template when nothing is saved
 *   - maps the gated responses to real panels: 403 before the contest starts
 *     (or after it ends) and 404 for an unknown problem id
 */

function isLanguage(v: string | null): v is Language {
  return v !== null && (LANGUAGES as readonly string[]).includes(v);
}

const codeKey = (problemId: number, lang: Language) => `codez-code:${problemId}:${lang}`;

export function IDE() {
  const { id } = useParams<{ id: string }>();
  const problemId = Number(id);

  const [problem, setProblem] = useState<ProblemDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [gate, setGate] = useState<'locked' | 'missing' | 'error' | null>(null);

  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('codez-lang');
    return isLanguage(saved) ? saved : 'python';
  });
  const [code, setCode] = useState('');

  // Load the problem when the route id changes.
  useEffect(() => {
    let alive = true;
    setLoading(true);
    setGate(null);
    api
      .problem(problemId)
      .then((p) => {
        if (!alive) return;
        setProblem(p);
        setLoading(false);
      })
      .catch((err) => {
        if (!alive) return;
        if (err instanceof ApiError && err.status === 403) setGate('locked');
        else if (err instanceof ApiError && err.status === 404) setGate('missing');
        else setGate('error');
        setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [problemId]);

  // Load saved code (or seed the template) whenever the problem or language changes.
  useEffect(() => {
    if (!problem) return;
    const saved = localStorage.getItem(codeKey(problem.id, language));
    setCode(saved !== null ? saved : BOILERPLATE[language]);
  }, [problem, language]);

  // Persist edits (debounced by React's batching is enough here).
  useEffect(() => {
    if (problem) localStorage.setItem(codeKey(problem.id, language), code);
  }, [code, problem, language]);

  useEffect(() => {
    localStorage.setItem('codez-lang', language);
  }, [language]);

  const onLanguageChange = useCallback((lang: Language) => setLanguage(lang), []);

  /* ---- split-pane divider drag (unchanged mechanics from files.zip) ---- */
  const [leftWidth, setLeftWidth] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);
  const draggingRef = useRef(false);

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      if (!draggingRef.current || !containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const pct = ((e.clientX - rect.left) / rect.width) * 100;
      if (pct > 30 && pct < 70) setLeftWidth(pct);
    };
    const onUp = () => {
      draggingRef.current = false;
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
    return () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };
  }, []);

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground gap-2">
        <Loader2 size={16} className="animate-spin motion-reduce:animate-none" />
        Loading problem…
      </div>
    );
  }

  if (gate === 'locked') {
    return (
      <Panel icon={<Lock size={22} className="text-amber-400" />} title="Not open yet">
        Problems unlock when the contest starts. Hang tight — the countdown is in the top bar.
      </Panel>
    );
  }
  if (gate === 'missing') {
    return (
      <Panel icon={<AlertTriangle size={22} className="text-destructive" />} title="Problem not found">
        This problem id doesn't exist in the running contest.
      </Panel>
    );
  }
  if (gate === 'error' || !problem) {
    return (
      <Panel icon={<AlertTriangle size={22} className="text-destructive" />} title="Couldn't load">
        Something went wrong reaching the server. Try again in a moment.
      </Panel>
    );
  }

  return (
    <div
      ref={containerRef}
      className="flex w-full h-full gap-3"
      style={{ userSelect: draggingRef.current ? 'none' : 'auto' }}
    >
      <div style={{ width: `${leftWidth}%` }} className="overflow-hidden">
        <ProblemPanel problem={problem} />
      </div>

      <div
        onMouseDown={() => {
          draggingRef.current = true;
        }}
        className="w-2 flex items-center justify-center cursor-col-resize flex-shrink-0 group relative z-10"
      >
        <div className="w-[1px] h-full bg-border" />
        <div className="absolute w-[2px] h-8 bg-accent/80 rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>

      <div style={{ width: `${100 - leftWidth}%` }} className="overflow-hidden">
        <CodeEditor
          code={code}
          onChange={setCode}
          language={language}
          onLanguageChange={onLanguageChange}
          problem={problem}
        />
      </div>
    </div>
  );
}

function Panel({
  icon,
  title,
  children,
}: {
  icon: ReactNode;
  title: string;
  children: ReactNode;
}) {
  return (
    <div className="h-full flex items-center justify-center">
      <div className="max-w-sm text-center">
        <div className="flex justify-center mb-3">{icon}</div>
        <h2 className="text-lg font-bold text-white mb-1">{title}</h2>
        <p className="text-sm text-muted-foreground">{children}</p>
      </div>
    </div>
  );
}
