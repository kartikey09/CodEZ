import { useEffect, useRef, useState } from 'react';
import type { ChangeEvent, KeyboardEvent, UIEvent } from 'react';
import { Button } from '@/components/ui/button';
import { ChevronDown, RotateCcw, Settings, Maximize2, Loader2 } from 'lucide-react';
import hljs from 'highlight.js/lib/core';
import cLang from 'highlight.js/lib/languages/c';
import cppLang from 'highlight.js/lib/languages/cpp';
import javaLang from 'highlight.js/lib/languages/java';
import pythonLang from 'highlight.js/lib/languages/python';
import 'highlight.js/styles/atom-one-dark.css';
import { api, ApiError, LANGUAGES } from '@/lib/api';
import type { Language, ProblemDetail, SubmissionStatus } from '@/lib/api';
import { BOILERPLATE } from '@/lib/boilerplate';
import { verdictMeta } from '@/lib/format';
import { useRealtime } from '@/lib/realtime';
import { VerdictBadge } from './verdict-badge';

/*
 * The files.zip editor (textarea + highlight.js overlay, draggable line-number
 * gutter, font-size menu, fullscreen, Tab/Enter handling) adapted to CodEZ:
 *
 *  - languages are the server's allowed set (c, cpp, java, python; hljs core build
 *    with just those four grammars registered instead of the full bundle)
 *  - the editable "test cases" tab became a read-only Samples tab: CodEZ judges
 *    hidden tests server-side, the client never sends test cases
 *  - Run/Submit collapsed into one Submit: POST /api/submissions -> 202
 *    {submissionId, status:"queued"}; the verdict arrives on the Day-10 WebSocket
 *    (fast path, usually < 1 s) while a 2 s poll of GET /api/submissions/{id}
 *    covers a dropped socket; whichever fires first, the poll result is the
 *    authoritative detail (failedTest, execTimeMs, memoryKb)
 *  - errors branch on HTTP status: 429 starts a visible cooldown on the button
 *    (mirrors the server's 10 s window), 409 one-in-flight, 413 too large,
 *    400 bad language, 403 outside the contest window
 *  - the CE line-highlight from files.zip is gone: the status endpoint reports
 *    a verdict + failed test index, not compiler output, so there is no line to mark
 */

hljs.registerLanguage('c', cLang);
hljs.registerLanguage('cpp', cppLang);
hljs.registerLanguage('java', javaLang);
hljs.registerLanguage('python', pythonLang);

interface CodeEditorProps {
  code: string;
  onChange: (code: string) => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  problem: ProblemDetail;
}

type Phase = 'idle' | 'submitting' | 'waiting' | 'done' | 'failed';

interface SubmitState {
  phase: Phase;
  submissionId: number | null;
  liveStatus: string | null; // 'queued' | 'running' while waiting
  result: SubmissionStatus | null;
  message: string | null; // rejection / error text
}

const IDLE: SubmitState = {
  phase: 'idle',
  submissionId: null,
  liveStatus: null,
  result: null,
  message: null,
};

export function CodeEditor({ code, onChange, language, onLanguageChange, problem }: CodeEditorProps) {
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [showSettingsMenu, setShowSettingsMenu] = useState(false);
  const [fontSize, setFontSize] = useState(14);
  const [gutterWidth, setGutterWidth] = useState(48);
  const [currentLine, setCurrentLine] = useState(1);
  const [scrollTop, setScrollTop] = useState(0);
  const [activeOutputTab, setActiveOutputTab] = useState<'samples' | 'result'>('samples');
  const [activeSample, setActiveSample] = useState(0);
  const [sub, setSub] = useState<SubmitState>(IDLE);
  const [cooldownLeft, setCooldownLeft] = useState(0);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const highlightRef = useRef<HTMLPreElement>(null);
  const editorContainerRef = useRef<HTMLDivElement>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const isDraggingGutterRef = useRef(false);

  const pollTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const unsubVerdict = useRef<(() => void) | null>(null);
  const pollCount = useRef(0);
  const { onVerdict } = useRealtime();

  const lineHeight = Math.round(fontSize * 1.6);

  /* ---------------- gutter drag (unchanged mechanics from files.zip) ---------------- */
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDraggingGutterRef.current || !editorContainerRef.current) return;
      const rect = editorContainerRef.current.getBoundingClientRect();
      const newWidth = e.clientX - rect.left;
      if (newWidth > 32 && newWidth < 200) setGutterWidth(newWidth);
    };
    const handleMouseUp = () => {
      isDraggingGutterRef.current = false;
    };
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  /* ---------------- syntax highlight overlay ---------------- */
  useEffect(() => {
    if (highlightRef.current) {
      highlightRef.current.innerHTML = hljs.highlight(code, {
        language,
        ignoreIllegals: true,
      }).value;
    }
  }, [code, language]);

  const handleScroll = (e: UIEvent<HTMLTextAreaElement>) => {
    if (highlightRef.current) {
      highlightRef.current.scrollTop = e.currentTarget.scrollTop;
      highlightRef.current.scrollLeft = e.currentTarget.scrollLeft;
    }
    setScrollTop(e.currentTarget.scrollTop);
  };

  const handleCodeChange = (e: ChangeEvent<HTMLTextAreaElement>) => {
    onChange(e.target.value);
    const before = e.target.value.substring(0, e.target.selectionStart);
    setCurrentLine(before.split('\n').length);
  };

  /* Tab = 4 spaces, Enter keeps indentation (from files.zip) */
  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const target = e.currentTarget;
      const start = target.selectionStart;
      const end = target.selectionEnd;
      onChange(code.substring(0, start) + '    ' + code.substring(end));
      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = textareaRef.current.selectionEnd = start + 4;
        }
      }, 0);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      const target = e.currentTarget;
      const start = target.selectionStart;
      const end = target.selectionEnd;
      const lines = code.substring(0, start).split('\n');
      const indent = lines[lines.length - 1].match(/^\s*/)?.[0] ?? '';
      const insert = '\n' + indent;
      onChange(code.substring(0, start) + insert + code.substring(end));
      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = textareaRef.current.selectionEnd =
            start + insert.length;
        }
      }, 0);
    }
  };

  const handleFullscreen = () => {
    if (!document.fullscreenElement) {
      rootRef.current?.requestFullscreen().catch(() => {});
    } else {
      void document.exitFullscreen();
    }
  };

  /* ---------------- submit -> WebSocket fast path + poll fallback ---------------- */

  const stopWatching = () => {
    if (pollTimer.current) {
      clearInterval(pollTimer.current);
      pollTimer.current = null;
    }
    if (unsubVerdict.current) {
      unsubVerdict.current();
      unsubVerdict.current = null;
    }
  };

  useEffect(() => stopWatching, []); // clean up timers/subscription on unmount

  useEffect(() => {
    if (cooldownLeft <= 0) return;
    const t = setInterval(() => setCooldownLeft((s) => (s > 1 ? s - 1 : 0)), 1000);
    return () => clearInterval(t);
  }, [cooldownLeft]);

  const refreshStatus = async (id: number) => {
    try {
      const status = await api.submission(id);
      if (status.status === 'done') {
        stopWatching();
        setSub({
          phase: 'done',
          submissionId: id,
          liveStatus: status.status,
          result: status,
          message: null,
        });
      } else {
        setSub((s) => (s.submissionId === id ? { ...s, liveStatus: status.status } : s));
      }
    } catch {
      /* transient — the next poll retries */
    }
  };

  const handleSubmit = async () => {
    if (sub.phase === 'submitting' || sub.phase === 'waiting' || cooldownLeft > 0) return;
    stopWatching();
    setActiveOutputTab('result');
    setSub({ phase: 'submitting', submissionId: null, liveStatus: null, result: null, message: null });

    try {
      const accepted = await api.submit(problem.id, language, code);
      const id = accepted.submissionId;
      setSub({
        phase: 'waiting',
        submissionId: id,
        liveStatus: accepted.status,
        result: null,
        message: null,
      });

      // Fast path: the realtime service pushes {submissionId, verdict} the moment
      // the worker publishes; fetch the authoritative record when it's ours.
      unsubVerdict.current = onVerdict((v) => {
        if (v.submissionId === id) void refreshStatus(id);
      });

      // Fallback: poll every 2 s (survives a dropped socket); ~3 min cap.
      pollCount.current = 0;
      pollTimer.current = setInterval(() => {
        pollCount.current += 1;
        if (pollCount.current > 90) {
          stopWatching();
          setSub((s) =>
            s.submissionId === id
              ? { ...s, phase: 'failed', message: 'The judge is taking unusually long. Check My submissions.' }
              : s,
          );
          return;
        }
        void refreshStatus(id);
      }, 2000);
    } catch (err) {
      if (err instanceof ApiError) {
        if (err.status === 429) {
          setCooldownLeft(10); // mirrors app.submission.cooldown-ms
          setSub({ ...IDLE, phase: 'failed', message: 'Slow down — one submission per 10 seconds.' });
        } else if (err.status === 409) {
          setSub({ ...IDLE, phase: 'failed', message: 'Your previous submission is still being judged.' });
        } else if (err.status === 413) {
          setSub({ ...IDLE, phase: 'failed', message: 'Source too large for the judge.' });
        } else if (err.status === 403) {
          setSub({ ...IDLE, phase: 'failed', message: err.message || 'The contest window is closed.' });
        } else {
          setSub({ ...IDLE, phase: 'failed', message: err.message || 'Submission rejected.' });
        }
      } else {
        setSub({ ...IDLE, phase: 'failed', message: 'Cannot reach the server.' });
      }
    }
  };

  const busy = sub.phase === 'submitting' || sub.phase === 'waiting';
  const lineCount = code.split('\n').length;
  const lineNumbers = Array.from({ length: lineCount }, (_, i) => i + 1);
  const samples = problem.samples;

  return (
    <div
      ref={rootRef}
      className="flex flex-col h-full bg-card border border-border rounded-lg overflow-hidden relative"
    >
      {/* Toolbar */}
      <div className="flex items-center justify-between px-4 h-[56px] border-b border-border/50 gap-4 bg-secondary/20 shrink-0">
        {/* Language selector — the server's allowed set */}
        <div className="relative">
          <button
            onClick={() => setShowLangMenu(!showLangMenu)}
            className="flex items-center gap-2 px-3 py-1.5 rounded bg-secondary border border-border text-foreground text-sm font-medium hover:bg-secondary/80 transition"
          >
            {language.charAt(0).toUpperCase() + language.slice(1)}
            <ChevronDown size={16} />
          </button>

          {showLangMenu && (
            <div className="absolute top-full left-0 mt-2 w-40 bg-secondary border border-border rounded-lg shadow-lg z-50">
              {LANGUAGES.map((lang) => (
                <button
                  key={lang}
                  onClick={() => {
                    onLanguageChange(lang);
                    setShowLangMenu(false);
                  }}
                  className={`w-full text-left px-4 py-2 text-sm transition ${
                    language === lang
                      ? 'bg-accent text-accent-foreground'
                      : 'text-foreground hover:bg-secondary/60'
                  }`}
                >
                  {lang.charAt(0).toUpperCase() + lang.slice(1)}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Utilities */}
        <div className="flex items-center gap-4 text-muted-foreground ml-auto mr-2 relative">
          <button
            onClick={() => onChange(BOILERPLATE[language])}
            className="hover:text-foreground transition"
            title="Reset to template"
          >
            <RotateCcw size={16} />
          </button>

          <button
            onClick={() => setShowSettingsMenu(!showSettingsMenu)}
            className="hover:text-foreground transition"
            title="Settings"
          >
            <Settings size={16} />
          </button>

          {showSettingsMenu && (
            <div className="absolute top-full right-0 mt-2 w-32 bg-secondary border border-border rounded-lg shadow-lg z-50 p-2">
              <p className="text-xs font-semibold text-muted-foreground mb-2 px-2">Font Size</p>
              {[12, 14, 16, 18, 20].map((size) => (
                <button
                  key={size}
                  onClick={() => {
                    setFontSize(size);
                    setShowSettingsMenu(false);
                  }}
                  className={`w-full text-left px-2 py-1.5 text-sm transition rounded ${
                    fontSize === size
                      ? 'bg-accent text-accent-foreground'
                      : 'text-foreground hover:bg-secondary/60'
                  }`}
                >
                  {size}px
                </button>
              ))}
            </div>
          )}

          <button onClick={handleFullscreen} className="hover:text-foreground transition" title="Fullscreen">
            <Maximize2 size={16} />
          </button>
        </div>

        <Button onClick={() => void handleSubmit()} disabled={busy || cooldownLeft > 0} className="font-medium">
          {busy ? (
            <>
              <Loader2 size={15} className="animate-spin motion-reduce:animate-none" />
              Judging…
            </>
          ) : cooldownLeft > 0 ? (
            `Wait ${cooldownLeft}s`
          ) : (
            'Submit'
          )}
        </Button>
      </div>

      {/* Editor surface */}
      <div ref={editorContainerRef} className="flex-1 flex overflow-hidden relative">
        {/* Line-number gutter (draggable width, from files.zip) */}
        <div
          style={{ width: gutterWidth }}
          className="bg-secondary/30 flex-shrink-0 overflow-hidden pt-3 relative"
        >
          <div
            className="font-mono text-muted-foreground/70 select-none flex flex-col items-end pr-3"
            style={{ fontSize: fontSize - 2, lineHeight: `${lineHeight}px`, transform: `translateY(${-scrollTop}px)` }}
          >
            {lineNumbers.map((n) => (
              <span key={n} className={n === currentLine ? 'text-accent' : undefined}>
                {n}
              </span>
            ))}
          </div>
          <div
            onMouseDown={() => {
              isDraggingGutterRef.current = true;
            }}
            className="absolute right-0 top-0 bottom-0 w-2 flex items-center justify-end cursor-col-resize z-10 group"
          >
            <div className="w-[1px] h-full bg-border/80 group-hover:bg-accent transition-colors" />
          </div>
        </div>

        {/* Code area: transparent textarea over the hljs-rendered pre */}
        <div className="flex-1 relative overflow-hidden bg-card">
          {/* current-line wash */}
          <div
            className="absolute left-0 right-0 bg-white/8 border-l-2 border-accent/50 pointer-events-none"
            style={{ top: 12 + (currentLine - 1) * lineHeight - scrollTop, height: lineHeight }}
          />
          <pre
            ref={highlightRef}
            aria-hidden="true"
            className="hljs absolute inset-0 pt-3 pb-4 px-4 font-mono overflow-hidden pointer-events-none whitespace-pre"
            style={{ fontSize, lineHeight: `${lineHeight}px` }}
          />
          <textarea
            ref={textareaRef}
            value={code}
            onChange={handleCodeChange}
            onKeyDown={handleKeyDown}
            onScroll={handleScroll}
            onClick={(e) => {
              const before = e.currentTarget.value.substring(0, e.currentTarget.selectionStart);
              setCurrentLine(before.split('\n').length);
            }}
            spellCheck={false}
            className="relative pt-3 pb-4 px-4 font-mono bg-transparent text-transparent caret-accent resize-none focus:outline-none w-full h-full overflow-auto whitespace-pre"
            style={{ fontSize, lineHeight: `${lineHeight}px` }}
          />
        </div>
      </div>

      {/* Bottom panel: Samples | Result */}
      <div className="border-t border-border bg-[#1A1A1A] flex flex-col shrink-0 h-[260px]">
        <div className="flex items-center gap-6 px-6 pt-1 border-b border-border/50">
          <button
            className={`px-2 py-2.5 text-sm font-medium border-b-2 transition-all ${
              activeOutputTab === 'samples'
                ? 'border-accent text-white'
                : 'border-transparent text-muted-foreground hover:text-white'
            }`}
            onClick={() => setActiveOutputTab('samples')}
          >
            Samples
          </button>
          <button
            className={`px-2 py-2.5 text-sm font-medium border-b-2 transition-all ${
              activeOutputTab === 'result'
                ? 'border-accent text-white'
                : 'border-transparent text-muted-foreground hover:text-white'
            }`}
            onClick={() => setActiveOutputTab('result')}
          >
            Result
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-4">
          {activeOutputTab === 'samples' ? (
            samples.length === 0 ? (
              <p className="text-sm text-muted-foreground">This problem has no visible samples.</p>
            ) : (
              <div>
                <div className="flex gap-2 mb-3">
                  {samples.map((s, i) => (
                    <button
                      key={s.ordinal}
                      onClick={() => setActiveSample(i)}
                      className={`px-3 py-1 rounded text-xs font-mono border transition ${
                        i === activeSample
                          ? 'bg-accent/15 border-accent/40 text-accent'
                          : 'border-border text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      Case {s.ordinal}
                    </button>
                  ))}
                </div>
                {samples[activeSample] && (
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <p className="text-[11px] font-mono text-muted-foreground mb-1">stdin</p>
                      <pre className="rounded-md border border-border bg-input px-3 py-2 font-mono text-xs whitespace-pre-wrap">
                        {samples[activeSample].input}
                      </pre>
                    </div>
                    <div>
                      <p className="text-[11px] font-mono text-muted-foreground mb-1">expected stdout</p>
                      <pre className="rounded-md border border-border bg-input px-3 py-2 font-mono text-xs whitespace-pre-wrap">
                        {samples[activeSample].expectedOutput}
                      </pre>
                    </div>
                  </div>
                )}
                <p className="text-xs text-muted-foreground mt-3">
                  Read-only: the judge runs these plus hidden tests on the server.
                </p>
              </div>
            )
          ) : (
            <ResultPane sub={sub} />
          )}
        </div>
      </div>
    </div>
  );
}

function ResultPane({ sub }: { sub: SubmitState }) {
  if (sub.phase === 'idle') {
    return <p className="text-sm text-muted-foreground">Submit to see the judge's verdict here.</p>;
  }
  if (sub.phase === 'submitting') {
    return <p className="text-sm text-muted-foreground font-mono">Sending to the queue…</p>;
  }
  if (sub.phase === 'failed') {
    return (
      <div className="text-sm text-destructive">
        {sub.message}
        {sub.submissionId != null && (
          <span className="text-muted-foreground"> (submission #{sub.submissionId})</span>
        )}
      </div>
    );
  }
  if (sub.phase === 'waiting') {
    return (
      <div className="text-sm font-mono text-muted-foreground">
        <p>
          Submission <span className="text-foreground">#{sub.submissionId}</span> —{' '}
          <span className="text-amber-400">{sub.liveStatus ?? 'queued'}</span>
        </p>
        <p className="mt-2 text-xs">
          Waiting for the judge… the verdict is pushed live; polling covers a dropped socket.
        </p>
      </div>
    );
  }
  // done
  const r = sub.result;
  if (!r) return null;
  return (
    <div className="text-sm">
      <div className="flex items-center gap-3">
        <VerdictBadge verdict={r.verdict} />
        <span className="text-foreground font-medium">{verdictMeta(r.verdict).label}</span>
        <span className="text-muted-foreground font-mono text-xs">#{r.id}</span>
      </div>
      <div className="mt-3 grid grid-cols-3 gap-3 max-w-md font-mono text-xs text-muted-foreground">
        <div>
          <p className="text-[10px] uppercase tracking-wider">time</p>
          <p className="text-foreground">{r.execTimeMs != null ? `${r.execTimeMs} ms` : '—'}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-wider">memory</p>
          <p className="text-foreground">{r.memoryKb != null ? `${r.memoryKb} KB` : '—'}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-wider">failed test</p>
          <p className="text-foreground">{r.failedTest != null ? `#${r.failedTest}` : '—'}</p>
        </div>
      </div>
      {r.verdict !== 'AC' && (
        <p className="mt-3 text-xs text-muted-foreground">
          Wrong attempts before an accepted one cost +20 min penalty each; compile errors cost
          nothing.
        </p>
      )}
    </div>
  );
}
