import type { Language } from './api';

/*
 * Starter code per language. CodEZ judges stdin -> stdout against hidden test cases
 * (Judge0 diffs the output), so the templates are I/O scaffolds — unlike the
 * LeetCode-style `class Solution { twoSum(...) }` stubs in files.zip, which fit a
 * judge that calls a named function. Submitting one of those here would WA/CE.
 *
 * Note for Java: the orchestrator compiles the file as Main.java, so the public
 * class must be named Main.
 */
export const BOILERPLATE: Record<Language, string> = {
  c: `#include <stdio.h>

int main(void) {
    // Read from stdin, write the answer to stdout.
    // e.g. two ints:  long long a, b; scanf("%lld %lld", &a, &b);
    return 0;
}
`,
  cpp: `#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    // Read from stdin, write the answer to stdout.
    return 0;
}
`,
  java: `import java.util.*;
import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        // Read from stdin, write the answer to stdout.
    }
}
`,
  python: `import sys

def main():
    data = sys.stdin.read().split()
    # Read from stdin, write the answer to stdout.

main()
`,
};
