import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { api, ApiError } from './api';
import type { ContestInfo } from './api';

/*
 * The running contest (GET /api/contest, added on the backend this same day) plus a
 * server-corrected clock. skew = serverEpochMillis - Date.now() at fetch time; every
 * countdown uses now() = Date.now() + skew, so a student whose laptop clock is five
 * minutes fast still sees the real remaining time. error === 'none' means the server
 * answered 404: no contest is in the running state.
 */

interface ContestState {
  contest: ContestInfo | null;
  error: 'none' | 'network' | null;
  now: () => number;
  refresh: () => Promise<void>;
}

const ContestContext = createContext<ContestState | null>(null);

export function ContestProvider({ children }: { children: ReactNode }) {
  const [contest, setContest] = useState<ContestInfo | null>(null);
  const [error, setError] = useState<'none' | 'network' | null>(null);
  const skewRef = useRef(0);

  const refresh = useCallback(async () => {
    try {
      const c = await api.contest();
      skewRef.current = c.serverEpochMillis - Date.now();
      setContest(c);
      setError(null);
    } catch (err) {
      setContest(null);
      setError(err instanceof ApiError && err.status === 404 ? 'none' : 'network');
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const now = useCallback(() => Date.now() + skewRef.current, []);

  const value = useMemo(() => ({ contest, error, now, refresh }), [contest, error, now, refresh]);

  return <ContestContext.Provider value={value}>{children}</ContestContext.Provider>;
}

export function useContest(): ContestState {
  const ctx = useContext(ContestContext);
  if (!ctx) throw new Error('useContest must be used inside <ContestProvider>');
  return ctx;
}
