import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { api, ApiError } from './api';
import type { Me } from './api';

/*
 * Who is signed in. The credential itself is the HttpOnly `sid` cookie — this
 * provider only holds the profile. On mount it asks /auth/me: 200 restores the
 * session across reloads, 401 means anonymous. login() returns the Me so the
 * caller can route on mustChangePassword (seeded accounts start with it true;
 * contest-api 403s every protected path until the password is changed).
 */

interface SessionState {
  me: Me | null;
  loading: boolean;
  login: (loginId: string, password: string) => Promise<Me>;
  logout: () => Promise<void>;
  refresh: () => Promise<Me | null>;
}

const SessionContext = createContext<SessionState | null>(null);

export function SessionProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const who = await api.me();
      setMe(who);
      return who;
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        setMe(null);
        return null;
      }
      throw err;
    }
  }, []);

  useEffect(() => {
    refresh()
      .catch(() => setMe(null))
      .finally(() => setLoading(false));
  }, [refresh]);

  const login = useCallback(async (loginId: string, password: string) => {
    const who = await api.login(loginId, password);
    setMe(who);
    return who;
  }, []);

  const logout = useCallback(async () => {
    try {
      await api.logout();
    } finally {
      setMe(null);
    }
  }, []);

  const value = useMemo(
    () => ({ me, loading, login, logout, refresh }),
    [me, loading, login, logout, refresh],
  );

  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}

export function useSession(): SessionState {
  const ctx = useContext(SessionContext);
  if (!ctx) throw new Error('useSession must be used inside <SessionProvider>');
  return ctx;
}
