/*
 * The single place the frontend touches the network. Talks to the CodEZ Java services
 * through the Vite dev proxy (vite.config.ts):
 *
 *   /auth/*  -> auth-service :8081      /api/*  -> contest-api :8080      /ws -> realtime :8083
 *
 * All paths are relative (API_BASE = ''), so the same code works in dev (Vite proxy) and
 * behind the eventual production reverse proxy. Auth is the server-set HttpOnly `sid`
 * cookie — fetch attaches it automatically on same-origin requests. Nothing auth-related
 * is stored in localStorage: the files.zip flow targeted a token backend; CodEZ is
 * cookie-session based and the browser never sees the credential.
 */

export const API_BASE = '';

/** Mirrors contest-api's ErrorResponse / auth-service error bodies: { code, message }. */
export interface ErrorResponse {
  code: string;
  message: string;
}

/** Thrown for any non-2xx. Handlers branch on `status`; `message` is shown to the user. */
export class ApiError extends Error {
  status: number;
  code: string;
  constructor(status: number, code: string, message: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const res = await fetch(API_BASE + path, {
    method,
    headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  if (res.status === 204) return undefined as T;
  const text = await res.text();
  let data: unknown;
  try {
    data = text ? JSON.parse(text) : undefined;
  } catch {
    data = undefined;
  }
  if (!res.ok) {
    const err = (data ?? {}) as Partial<ErrorResponse>;
    throw new ApiError(res.status, err.code ?? `HTTP_${res.status}`, err.message ?? res.statusText);
  }
  return data as T;
}

/* ---------- DTOs (each mirrors a Java record — keep field names in lockstep) ---------- */

/** auth-service MeResponse */
export interface Me {
  userId: number;
  loginId: string;
  displayName: string;
  role: string; // 'student' | 'admin'
  mustChangePassword: boolean;
}

/** contest-api ContestInfo (Day 11's GET /api/contest) */
export interface ContestInfo {
  id: number;
  title: string;
  startsAt: string; // ISO instant
  endsAt: string; // ISO instant
  state: string; // 'running'
  serverEpochMillis: number; // for clock-skew correction
}

/** contest-api ProblemSummary */
export interface ProblemSummary {
  id: number;
  label: string;
  title: string;
}

/** contest-api SampleTest */
export interface SampleTest {
  ordinal: number;
  input: string;
  expectedOutput: string;
}

/** contest-api ProblemDetail */
export interface ProblemDetail {
  id: number;
  label: string;
  title: string;
  statementMd: string;
  timeLimitMs: number;
  memoryLimitMb: number;
  samples: SampleTest[];
}

/** contest-api SubmissionAccepted — POST /api/submissions returns 202 with this */
export interface SubmissionAccepted {
  submissionId: number;
  status: string; // 'queued'
}

/** contest-api SubmissionSummary (GET /api/submissions/mine rows) */
export interface SubmissionSummary {
  id: number;
  problemId: number;
  language: string;
  status: string; // 'queued' | 'running' | 'done'
  verdict: string | null; // AC | WA | TLE | MLE | RE | CE | IE — null until judged
  createdAt: string;
}

/** contest-api SubmissionStatusResponse (GET /api/submissions/{id}) */
export interface SubmissionStatus {
  id: number;
  problemId: number;
  language: string;
  status: string; // 'queued' | 'running' | 'done'
  verdict: string | null;
  failedTest: number | null;
  execTimeMs: number | null;
  memoryKb: number | null;
  createdAt: string;
  judgedAt: string | null;
}

/** contest-api StandingsResponse.Cell — state is "solved" | "attempted" | "none" */
export interface StandingsCell {
  label: string;
  state: 'solved' | 'attempted' | 'none';
  attempts: number;
  acMinute: number | null;
}

/** contest-api StandingsResponse.Row */
export interface StandingsRow {
  rank: number;
  userId: number;
  displayName: string;
  solved: number;
  penalty: number;
  cells: StandingsCell[];
}

/** contest-api StandingsResponse */
export interface Standings {
  contestId: number;
  problems: string[];
  rows: StandingsRow[];
  generatedAt: string;
}

/** contest-api MyStanding (GET /api/contests/{id}/standings/me) */
export interface MyStanding {
  contestId: number;
  userId: number;
  rank: number | null;
  solved: number;
  penalty: number;
  cells: StandingsCell[];
}

/** Mirrors contest-api app.submission.allowed-languages — keep in sync with application.yml. */
export const LANGUAGES = ['c', 'cpp', 'java', 'python'] as const;
export type Language = (typeof LANGUAGES)[number];

/* ---------------------------------- endpoints ---------------------------------- */

export const api = {
  // auth-service
  login: (loginId: string, password: string) =>
    request<Me>('POST', '/auth/login', { loginId, password }),
  me: () => request<Me>('GET', '/auth/me'),
  changePassword: (currentPassword: string, newPassword: string) =>
    request<void>('POST', '/auth/change-password', { currentPassword, newPassword }),
  logout: () => request<void>('POST', '/auth/logout'),

  // contest-api
  contest: () => request<ContestInfo>('GET', '/api/contest'),
  problems: () => request<ProblemSummary[]>('GET', '/api/problems'),
  problem: (id: number) => request<ProblemDetail>('GET', `/api/problems/${id}`),
  submit: (problemId: number, language: Language, sourceCode: string) =>
    request<SubmissionAccepted>('POST', '/api/submissions', { problemId, language, sourceCode }),
  mySubmissions: () => request<SubmissionSummary[]>('GET', '/api/submissions/mine'),
  submission: (id: number) => request<SubmissionStatus>('GET', `/api/submissions/${id}`),
  standings: (contestId: number, limit = 200) =>
    request<Standings>('GET', `/api/contests/${contestId}/standings?limit=${limit}`),
  myStanding: (contestId: number) =>
    request<MyStanding>('GET', `/api/contests/${contestId}/standings/me`),
};
