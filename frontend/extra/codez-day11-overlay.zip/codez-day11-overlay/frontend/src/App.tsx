import { BrowserRouter, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { SessionProvider, useSession } from '@/lib/session';
import { Login } from '@/components/login';
import { ChangePassword } from '@/components/change-password';
import { Shell } from '@/components/shell';
import { Problems } from '@/components/problems';
import { IDE } from '@/components/ide';
import { Standings } from '@/components/standings';
import { Submissions } from '@/components/submissions';

/*
 * Routing + the session provider at the root. Two full-screen routes live outside
 * the Shell (login, forced password change); everything else renders inside Shell,
 * which gates on the session and mounts the contest + realtime providers.
 */

function LoginRoute() {
  const { me } = useSession();
  const navigate = useNavigate();
  // Already signed in? Skip the form. mustChange goes to the change screen.
  if (me) return <Navigate to={me.mustChangePassword ? '/change-password' : '/problems'} replace />;
  return (
    <Login
      onLogin={(who) => navigate(who.mustChangePassword ? '/change-password' : '/problems', { replace: true })}
    />
  );
}

function ChangePasswordRoute() {
  const { me, loading } = useSession();
  const navigate = useNavigate();
  if (loading) return null;
  if (!me) return <Navigate to="/login" replace />;
  return <ChangePassword onDone={() => navigate('/problems', { replace: true })} />;
}

export default function App() {
  return (
    <BrowserRouter>
      <SessionProvider>
        <Routes>
          <Route path="/login" element={<LoginRoute />} />
          <Route path="/change-password" element={<ChangePasswordRoute />} />
          <Route element={<Shell />}>
            <Route path="/problems" element={<Problems />} />
            <Route path="/problems/:id" element={<IDE />} />
            <Route path="/standings" element={<Standings />} />
            <Route path="/submissions" element={<Submissions />} />
          </Route>
          <Route path="*" element={<Navigate to="/problems" replace />} />
        </Routes>
      </SessionProvider>
    </BrowserRouter>
  );
}
