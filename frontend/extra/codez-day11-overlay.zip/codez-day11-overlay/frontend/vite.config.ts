import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { fileURLToPath, URL } from 'node:url'

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  // Where the CodEZ services are reachable during local `npm run dev`.
  // All app code uses relative paths (API_BASE = ''); the dev server forwards
  // them, so cookies stay first-party and no service needs CORS headers.
  //   /auth -> auth-service        /api -> contest-api        /ws -> realtime (WebSocket)
  const auth = env.VITE_AUTH_ORIGIN || 'http://localhost:8081'
  const api = env.VITE_API_ORIGIN || 'http://localhost:8080'
  const ws = env.VITE_WS_ORIGIN || 'ws://localhost:8083'

  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': fileURLToPath(new URL('./src', import.meta.url)),
      },
    },
    server: {
      host: true,
      port: 5173,
      proxy: {
        '/auth': { target: auth, changeOrigin: true },
        '/api': { target: api, changeOrigin: true },
        '/ws': { target: ws, ws: true, changeOrigin: true },
      },
    },
  }
})
