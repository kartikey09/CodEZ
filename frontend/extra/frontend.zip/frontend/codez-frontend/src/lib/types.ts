// Mirrors the contest-platform DTOs (services/auth + services/contest-api).
// Field names match the Java records exactly so JSON maps 1:1.

export type Role = 'student' | 'admin' | string

/** /auth/me and /auth/login response (MeResponse). */
export interface Me {
  userId: number
  loginId: string
  displayName: string
  role: Role
  mustChangePassword: boolean
}

/** GET /api/problems row (ProblemSummary). */
export interface ProblemSummary {
  id: number
  label: string // "A", "B", ...
  title: string
}

/** One sample test shown on a problem (SampleTest). */
export interface SampleTest {
  ordinal: number
  input: string
  expectedOutput: string
}

/** GET /api/problems/{id} (ProblemDetail). */
export interface ProblemDetail {
  id: number
  label: string
  title: string
  statementMd: string
  timeLimitMs: number
  memoryLimitMb: number
  samples: SampleTest[]
}

/** The four languages contest-api accepts (app.submission.allowed-languages). */
export type Language = 'c' | 'cpp' | 'java' | 'python'

/** 202 body from POST /api/submissions (SubmissionAccepted). */
export interface SubmissionAccepted {
  submissionId: number
  status: string // "queued"
}

/** submissions.status lifecycle: queued -> running -> done. */
export type SubmissionStatus = 'queued' | 'running' | 'done'

/** submissions.verdict, set once status === "done". */
export type Verdict = 'AC' | 'WA' | 'TLE' | 'MLE' | 'RE' | 'CE' | 'IE'

/** GET /api/submissions/{id} (SubmissionStatusResponse). */
export interface SubmissionStatusResponse {
  id: number
  problemId: number
  language: string
  status: SubmissionStatus
  verdict: Verdict | null
  failedTest: number | null
  execTimeMs: number | null
  memoryKb: number | null
  createdAt: string
  judgedAt: string | null
}

/** GET /api/submissions/mine row (SubmissionSummary). */
export interface SubmissionSummary {
  id: number
  problemId: number
  language: string
  status: SubmissionStatus
  verdict: Verdict | null
  createdAt: string
}

/** GET /api/time (TimeResponse). */
export interface TimeResponse {
  serverTime: string
  epochMillis: number
}

// ----- leaderboard (StandingsResponse) -----

export type CellState = 'solved' | 'attempted' | 'none'

export interface StandingsCell {
  label: string
  state: CellState
  attempts: number
  acMinute: number | null
}

export interface StandingsRow {
  rank: number
  userId: number
  displayName: string
  solved: number
  penalty: number
  cells: StandingsCell[]
}

export interface StandingsResponse {
  contestId: number
  problems: string[]
  rows: StandingsRow[]
  generatedAt: string
}

// ----- admin user management (services/auth, Day 12) -----

/** GET /auth/admin/users row (AdminUserView). */
export interface AdminUser {
  id: number
  loginId: string
  displayName: string
  role: Role
  active: boolean
  mustChangePassword: boolean
  createdAt: string | null
}

/**
 * Result of creating an account (CreatedUser). `initialPassword` is the one-time
 * plaintext to hand to the student — present only when the server generated it
 * (null when the admin supplied their own password).
 */
export interface CreatedUser {
  id: number
  loginId: string
  displayName: string
  role: Role
  initialPassword: string | null
}

/** A row the roster import refused to create (ImportResult.Skipped). */
export interface SkippedRow {
  line: number
  loginId: string
  reason: string
}

/** POST /auth/admin/users/import response (ImportResult). */
export interface ImportResult {
  created: CreatedUser[]
  skipped: SkippedRow[]
}

/** POST /auth/admin/users/{id}/reset-password response (ResetResult). */
export interface ResetResult {
  id: number
  loginId: string
  initialPassword: string
}
